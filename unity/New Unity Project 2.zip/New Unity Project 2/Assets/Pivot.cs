﻿using UnityEngine;
using System.Collections;

public class Pivot : MonoBehaviour {

    Vector3 pointPivot;
    public GameObject pivot;
    Vector3 vectAxePivot;
    float timer;
    public float angle;
    public float tempsRotation;

            
	// Use this for initialization
	void Start () {
        pointPivot = pivot.transform.position;
        vectAxePivot = (Vector3.Cross(pointPivot - transform.position, pivot.transform.right));


        vectAxePivot.Normalize();

	}
	
	// Update is called once per frame
	void Update () {

        transform.RotateAround(pointPivot, vectAxePivot, angle * Time.deltaTime);

	
	}
}
