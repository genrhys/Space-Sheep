﻿using UnityEngine;
using System.Collections;

public class player : MonoBehaviour {
    Rigidbody rb;

    float horizontalInputValue;
    float verticalInputValue;
    float mousexInputValue;
    float mouseyInputValue;

    public float vitesseHorizontal;
    public float vitesseVertical;
    public float vitesseSourisX;
    public float vitesseSourisY;
    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        if (!Input.GetKey(KeyCode.LeftAlt)) {
            mouvement();
        }
            

    
	
	}

    void mouvement() {
        horizontalInputValue = Input.GetAxis("Horizontal");
        verticalInputValue  = Input.GetAxis("Vertical");
        mousexInputValue  = Input.GetAxis("Mouse X");
        mouseyInputValue = Input.GetAxis("Mouse Y");

        Vector3 mvtvertical = -verticalInputValue * Time.deltaTime * transform.forward * vitesseVertical;
        Vector3 mvthorizontal = horizontalInputValue * Time.deltaTime * transform.right * vitesseHorizontal;

        rb.MovePosition(rb.position + mvtvertical + mvthorizontal);

        float sourisY = vitesseSourisY * mouseyInputValue * Time.deltaTime;
        float sourisX = vitesseSourisX * mousexInputValue * Time.deltaTime;

        rb.rotation = Quaternion.Euler(rb.rotation.eulerAngles + new Vector3(sourisY, sourisX, 0.0f));

    }
}
